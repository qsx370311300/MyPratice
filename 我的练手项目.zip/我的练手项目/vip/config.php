<?php

define("DB_HOST","localhost");
define("DB_USER",'root');
define("DB_PASSWORD",'zhouxin123');
define("DB_DATABASE",'vip_user');
define("DB_CHARSET",'utf8');

?>