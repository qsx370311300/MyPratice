<?php
header("Content-Type:text/html;charset=utf-8");
$link = mysqli_connect("localhost","root","qsxqsx","test9");
if(mysqli_connect_errno($link)){
    exit (mysqli_connect_error($link));
}
mysqli_set_charset($link,"utf-8");
    $index = $_GET["j"];

    $sql = "select src from imgs where id=$index";

    $result = mysqli_query($link,$sql);

    while($row = mysqli_fetch_assoc($result)){
             echo $row['src'];
         }
?>